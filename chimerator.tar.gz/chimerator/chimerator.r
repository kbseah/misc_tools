breakpointreference <- function(numcols) {
# Calculate values of the breakpoint function
# For each possible sequence, how many breakpoints are there?
# Beware: vector index is offset by +1

# Have to check that numcols > 0

A <- rep(0,2^numcols) # create empty vector 
if (numcols == 1) { return(A) }					# If numcols==1, then both elements already 0
else {
  for (k in 2:numcols ) {
    for (a in 1:((2^(k-1)/2))) {A[a] <- A[a]}			# Carry forward first quarter
    for (a in (((2^(k-1)/2)+1):((2^k)/2))) {A[a] <- A[a] + 1}	# Increment second quarter
    for (a in (((2^k)/2)+1):(2^k)) {A[a] <- A[(2^k)-a+1]}	# Mirror remaining values
  }
}
return(A)
}


breakpointcounter <- function(bpref, Seq) {
# Calculate total number of breakpoints in an alignment vector Seq
# Assumes that breakpoint function has already been calculated for the numcols, values in bpref

P <- rep(0,length(Seq))
for (i in (0:length(Seq))){
  P[i] <- bpref[Seq[i]+1]
}
return(sum(P))
}


flipbits <- function(Seq, newcode,numcols) {
# Given a new encoding newcode for the first line in Seq, return the same alignment with the appropriate bits flipped
newSeq <- Seq
newSeq[1] <- newcode
for (j in 0:numcols){
  if (((newcode/(2^j))%%2)<1 ) {}	# if in binary column j, the newcode contains a "0" - do nothing
  else {				# if in binary column j, the newcode contains a "1", flip the rest of the column
    for (l in 2:length(Seq)) {
      if (((Seq[l]/(2^j))%%2)<1) {newSeq[l] <- newSeq[l] + 2^j}		# flip by addition if binary column j is 0
      else {newSeq[l] <- newSeq[l] - 2^j}				# flip by subtraction if binary column j is 1
    }
  }
}
return(newSeq)
}



chimerator <- function(Seq,numcols) {
# Exhaustive parsimony checker to minimize alignment chimerism
# Input: Seq - binary alignment converted to decimal, and numcols: number of columns in alignment
# Returns: bkpts - list of total # of breakpoints for each possible reencoding, and offsets - the new encoding offset which minimizes the total number of breakpoints
if (Seq[1] != 0) {return(print("First line of alignment must be 0"))} # check that alignment firstline is zero
else {
bkpts <- rep(0,2^numcols) # counter for total breakpoints per encoding
bpref <- breakpointreference(numcols) # generate breakpoint function values
bkpts[1] <- breakpointcounter(bpref,Seq) # Calculate baseline no. of breakpoints
for (m in 2:(2^numcols)) {
  newSeq <- flipbits(Seq,(m-1),numcols)
  bkpts[m] <- breakpointcounter(bpref,newSeq)
}
offsets <- which(bkpts==min(bkpts)) - 1
return(list("breakpoints"=bkpts,"offsets"=offsets))
}

}